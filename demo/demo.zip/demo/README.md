An API for searching repositories and owner's of repositories of GitHub accounts with provided username.

can be checked in postman with following path:

http://localhost:8080/api/repositories?username=${username}

